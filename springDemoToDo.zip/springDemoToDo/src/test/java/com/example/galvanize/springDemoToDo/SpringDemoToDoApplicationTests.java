package com.example.galvanize.springDemoToDo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoToDoApplicationTests {

	@Test
	void contextLoads() {
	}

}
