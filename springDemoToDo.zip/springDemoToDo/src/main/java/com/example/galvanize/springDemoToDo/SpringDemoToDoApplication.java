package com.example.galvanize.springDemoToDo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDemoToDoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDemoToDoApplication.class, args);
	}

}
